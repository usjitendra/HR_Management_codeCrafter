import express from "express";
import AppError from "../util/appError.js";
import employeModel from "../models/employeeModel.js";
import employeeWorkModel from "../models/employee.work.information.model.js";

const work_Add = async (req, res, next) => {
  try {
    const { id } = req.params;
    const {
      department,
      shiftInformation,
      reportingManger,
      workLocation,
      jobPosition,
      workType,
      salary,
      company,
      joiningDate,
      tags,
    } = req.body;
    const validateEmployee = await employeModel.findById(id);
    if (!validateEmployee) {
      return next(new AppError("Employee have not validat", 400));
    }

    const result = await employeeWorkModel.create({
      employeeId: id,
      department,
      shiftInformation,
      reportingManger,
      workLocation,
      jobPosition,
      workType,
      salary,
      company,
      joiningDate,
      tags,
    },{new:true});

    if(result){
        return res.status(200).json({success:true,message:"Success",result})
    }
    return next(new AppError("Some Error Accured",400));
  } catch (err) {
    return next(new AppError(err.message, 500));
  }
};

const worka_update = async (req, res, next) => {
    try {
        const { id } = req.params;
        const {
          department,
          shiftInformation,
          reportingManger,
          workLocation,
          jobPosition,
          workType,
          salary,
          company,
          joiningDate,
          tags,
        } = req.body;

        const result = await employeeWorkModel.findByIdAndUpdate(id,{
          employeeId: id,
          department,
          shiftInformation,
          reportingManger,
          workLocation,
          jobPosition,
          workType,
          salary,
          company,
          joiningDate,
          tags,
          $inc: { __v: 1 },
        },{new:true});
    
        if(result){
            return res.status(200).json({success:true,message:"Update success",result})
        }
        return next(new AppError("Some Error Accured",400));
      } catch (err) {
        return next(new AppError(err.message, 500));
      }
};

const work_delete = async (req, res, next) => {
  try {
    const{id}=req.params;
    const result=await employeeWorkModel.findByIdAndDelete(id);
    if(result){
        return res.status(200).json({success:true,message:"Work delete "});
    }
        return next(new AppError("Some Error occured",400));
  } catch (err) {
    return next(new AppError(err.message, 500));
  }
};

const work_aAdd = async (req, res, next) => {
  try {
  } catch (err) {
    return next(new AppError(err.message, 500));
  }
};

const worask_Add = async (req, res, next) => {
  try {
  } catch (err) {
    return next(new AppError(err.message, 500));
  }
};

export { work_Add,worka_update,work_delete };
