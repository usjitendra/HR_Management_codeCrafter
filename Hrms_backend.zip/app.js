import dotenv from "dotenv";
import express from'express'
import cors from 'cors'
import bodyParser from 'body-parser'
import multer from 'multer';
import dbConnection from "./config/dbConnection.js";
import errorMiddleware from "./middlewares/errorMiddleware.js";
import cookieParser from 'cookie-parser'
import employee from "./routes/employee.routes.js";
import attandance from "./routes/attandance.routes.js";
import admin from "./routes/admin.routes.js";
import cloudinary from 'cloudinary'
import bank from "./routes/bank.routes.js";
import work from "./routes/employee.work.routes.js"



cloudinary.v2.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
})

const app=express();
dotenv.config();

app.use(cors({
  origin: ["http://localhost:5173","http://localhost:3000","https://hrms112.netlify.app","hrms112.netlify.app","http://localhost:3001"], 
  credentials: true,
}));

const upload=multer({dist:"uploads/"})


app.get('/',(req,res)=>{
  // res.send({satatu:200,message:"server start"})
  res.status(200).json({
     success:true,
     message:"Service is Running "
  })
})

app.use(express.urlencoded({ extended: true }));
app.use(express.json())
app.use(bodyParser.urlencoded({extended:true}));
app.use(cookieParser());


app.use('/api/v1/admin',admin)
app.use('/api/v1/employee',employee)
app.use("/api/v1/employee/attendance",attandance)
app.use('/api/v1/employee/bank',bank)
app.use('/api/v1/employee/work',work)





app.use("*", (req, res) => {
    return res.status(404).json({ Message: "Route not found", path: req.originalUrl, method: req.method });
});

app.use(errorMiddleware)


const PORT=process.env.PORT||6000;
console.log(PORT);

app.listen(PORT,async()=>{
    await dbConnection()
    console.log(`server start on port ${PORT}`);
})




