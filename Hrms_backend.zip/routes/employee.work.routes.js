import { Router } from "express";
const employeeWorkRout=Router();

import { work_Add,worka_update,work_delete } from "../controllers/employee.work.controller.js";


employeeWorkRout.post('/add/:id',work_Add)
employeeWorkRout.put('/update/:id',worka_update)
employeeWorkRout.delete('/delete/:id',work_delete)


export default employeeWorkRout;